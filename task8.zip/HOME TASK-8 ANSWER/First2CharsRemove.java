
public class Remove21st 
{

	public String delete(String s) 
	{
		StringBuilder sb=new StringBuilder(s);
		String final;
		if(s.charAt(0)=='A'&&str.charAt(1)=='A')
			sb=sb.delete(0, 2);
		else if(s.charAt(0)=='A'||s.charAt(1)=='A')
			sb=sb.deleteCharAt(s.indexOf('A'));
		final=sb.toString();
		return final;
	}

}
